Dreambox NTP Sync 1.2.0 - DreamOS edition
=========================================

الأجهزة والصور المستهدفة:
- أجهزة Dreambox DM900 وDM920 وDreambox One وDreambox Two.
- معماريات ARM وAArch64 التي تستخدمها هذه الأجهزة.
- Python 2.7 وPython 3.
- نظام DreamOS الذي يستخدم systemd وحزم DEB.

الوظيفة:
- يوقف اعتماد Enigma2 على توقيت القناة أو الترانسبوندر.
- يضبط وقت Linux بواسطة NTP قبل تشغيل Enigma2 قدر الإمكان.
- ينتظر الإنترنت بحد أقصى 6 ثوانٍ فقط، ولا يمنع إقلاع الجهاز عند فشل الشبكة.
- إذا لم يكن الإنترنت جاهزًا، يعيد المحاولة في الخلفية كل 10 ثوانٍ لمدة تقارب 5 دقائق من دون تعطيل واجهة Enigma2.
- يعيد مزامنة الوقت كل 30 دقيقة.
- يضيف شاشة Dreambox NTP Sync إلى قائمة Plugins للتحكم اليدوي ومراجعة حالة المزامنة.
- يقرأ رقم إصدار البلاغين من ملف ver.txt الموجود داخل مجلد البلاغين ويعرضه في القائمة والشاشة.
- تستخدم الشاشتان الخلفية الزرقاء الخاصة بالإضافة، بينما تأخذ قائمة الإعدادات خطها وألوانها وشريط التحديد من الاسكين النشط لتجنب التعارض.
- يختار Python الموجود في الصورة تلقائيًا، ولا يحتوي على ملف تنفيذي خاص بمعمارية واحدة.
- يعمل في الخلفية ولا يعرض رسائل منبثقة على الشاشة.

الخوادم بالترتيب:
1. 162.159.200.1 (Cloudflare IPv4 Anycast، بدون انتظار DNS)
2. 0.africa.pool.ntp.org
3. 1.africa.pool.ntp.org
4. 0.pool.ntp.org

التصحيح اليدوي:
- من قائمة Plugins افتح Dreambox NTP Sync، ثم اضغط الزر الأخضر لفتح Manual Mode.
- تعرض شاشة NTP الوقت المحلي ووقت الإنترنت والفرق بينهما، مع أزرار الخروج والوضع اليدوي والتحديث والإزالة.
- على الاسكينات التي تعرض الأحمر والأخضر فقط، يفتح الأخضر Manual Mode، ويمكن اختيار Synchronize with NTP أو Refresh Internet Time من القائمة والضغط على OK.
- تعرض شاشة Manual Mode حقول السنة والشهر واليوم والساعة والدقيقة والثانية داخل قائمة Setup القياسية للاسكين.
- داخل الوضع اليدوي: الأسهم وأزرار الأرقام لتغيير القيم، والأخضر للحفظ، والأحمر للعودة إلى وضع NTP.
- لتصحيح الوقت فورًا، نفّذ:
   /usr/bin/dreambox-ntp-sync --manual
- يعيد الأمر المحاولة كل 5 ثوانٍ لمدة دقيقة تقريبًا، ويعيد رمز خطأ إذا لم يتوفر الإنترنت.

التثبيت بواسطة الحزمة:
- تتطلب الحزمة صورة تستخدم مدير الحزم dpkg وتدعم ملفات DEB.
- عند تثبيت الإصدار 1.2.0 فوق إصدار سابق، يتولى مدير الحزم استبدال ملفات الحزمة القديمة تلقائيًا.

التثبيت اليدوي على صورة systemd:
1. انسخ محتويات هذا المجلد فوق جذر ملفات الصورة مع الحفاظ على المسارات.
2. نفّذ:
   chmod 755 /usr/bin/dreambox-ntp-sync
   chmod 644 /usr/lib/dreambox-ntp-sync.py
   chmod 644 /lib/systemd/system/dreambox-ntp-sync.service
   chmod 644 /lib/systemd/system/dreambox-ntp-sync-retry.service
   chmod 644 /lib/systemd/system/dreambox-ntp-sync.timer
   chmod 644 /etc/systemd/system/enigma2.service.d/10-dreambox-ntp-sync.conf
   systemctl daemon-reload
   systemctl enable --now dreambox-ntp-sync.timer
   systemctl restart enigma2

الفحص على systemd:
   systemctl status dreambox-ntp-sync.service
   systemctl status dreambox-ntp-sync.timer
   cat /tmp/dreambox-ntp-sync.log

الفحص على أي صورة:
   /usr/bin/dreambox-ntp-sync --version
   /usr/bin/dreambox-ntp-sync --manual
   /usr/bin/dreambox-ntp-sync --quick
   cat /tmp/dreambox-ntp-sync.log
   date

ملاحظة:
- احذف أو عطّل أي إضافة أخرى لمزامنة الوقت حتى لا تعمل طريقتان لضبط الساعة في الوقت نفسه.

إلغاء الحزمة:
- للإزالة الكاملة والتنظيف نفّذ: apt-get purge dreambox-ntp-sync -y
- تحفظ الحزمة قيمة useTransponderTime قبل التثبيت وتستعيدها عند الإزالة، من دون إعادة بقية ملف إعدادات Enigma2 للخلف.
- توقف سكربتات control الخدمات والمؤقت وتحذف ملفات الإضافة والكاش والسجل والقفل، ثم تعيد تشغيل Enigma2 إذا كان يعمل.
