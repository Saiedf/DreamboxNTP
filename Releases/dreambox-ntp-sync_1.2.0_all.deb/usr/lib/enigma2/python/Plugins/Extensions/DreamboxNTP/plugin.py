#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function

import datetime
import io
import os
import time

from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.Console import Console
from Components.Sources.StaticText import StaticText
from Components.config import ConfigInteger, ConfigSelection, NoSave, getConfigListEntry
from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen


__author__ = "iet5"

SYNC_COMMAND = "/usr/bin/dreambox-ntp-sync --manual"
PROBE_COMMAND = "/usr/bin/dreambox-ntp-sync --probe"
VERSION_FILE = os.path.join(os.path.dirname(__file__), "ver.txt")
BACKGROUND_FILE = os.path.join(os.path.dirname(__file__), "background.png")
BUTTONS_DIR = os.path.join(os.path.dirname(__file__), "buttons")
RED_BUTTON = os.path.join(BUTTONS_DIR, "red.png")
GREEN_BUTTON = os.path.join(BUTTONS_DIR, "green.png")
YELLOW_BUTTON = os.path.join(BUTTONS_DIR, "yellow.png")
BLUE_BUTTON = os.path.join(BUTTONS_DIR, "blue.png")


# Keep list fonts and colors under the active DreamOS skin.
NTP_SCREEN_SKIN = """
<screen name="DreamboxNTPScreen" position="center,center" size="1280,820"
        flags="wfNoBorder" backgroundColor="#00030A12">
    <ePixmap pixmap="%s" position="0,0" size="1280,820"
             zPosition="-10" alphatest="blend" />
    <widget source="Title" render="Label" position="80,36" size="1120,50"
            font="Regular;36" foregroundColor="#0000D9FF"
            backgroundColor="#00030A12" transparent="1" halign="center" />
    <widget source="subtitle" render="Label" position="120,90" size="1040,34"
            font="Regular;23" foregroundColor="#00D6EEFF"
            backgroundColor="#00030A12" transparent="1" halign="center" />
    <widget name="config" position="145,170" size="990,364" itemHeight="52"
            transparent="1" scrollbarMode="showOnDemand" />
    <eLabel position="143,590" size="994,50" zPosition="1"
            backgroundColor="#006AC9E8" />
    <widget source="description" render="Label" position="146,593" size="988,44"
            zPosition="2" font="Regular;22" foregroundColor="#00FFFFFF"
            backgroundColor="#00203E5C" transparent="0"
            halign="center" valign="center" />
    <ePixmap pixmap="%s" position="80,720" size="220,48"
             zPosition="1" alphatest="blend" />
    <ePixmap pixmap="%s" position="380,720" size="220,48"
             zPosition="1" alphatest="blend" />
    <ePixmap pixmap="%s" position="680,720" size="220,48"
             zPosition="1" alphatest="blend" />
    <ePixmap pixmap="%s" position="980,720" size="220,48"
             zPosition="1" alphatest="blend" />
    <widget source="key_red" render="Label" position="80,720" size="220,48"
            zPosition="2" font="Regular;27" foregroundColor="#00FFFFFF"
            transparent="1" shadowColor="#00000000" shadowOffset="2,2"
            halign="center" valign="center" />
    <widget source="key_green" render="Label" position="380,720" size="220,48"
            zPosition="2" font="Regular;27" foregroundColor="#00FFFFFF"
            transparent="1" shadowColor="#00000000" shadowOffset="2,2"
            halign="center" valign="center" />
    <widget source="key_yellow" render="Label" position="680,720" size="220,48"
            zPosition="2" font="Regular;27" foregroundColor="#00000000"
            transparent="1"
            halign="center" valign="center" />
    <widget source="key_blue" render="Label" position="980,720" size="220,48"
            zPosition="2" font="Regular;27" foregroundColor="#00FFFFFF"
            transparent="1" shadowColor="#00000000" shadowOffset="2,2"
            halign="center" valign="center" />
</screen>
""" % (BACKGROUND_FILE, RED_BUTTON, GREEN_BUTTON, YELLOW_BUTTON, BLUE_BUTTON)


MANUAL_SCREEN_SKIN = NTP_SCREEN_SKIN.replace(
    'name="DreamboxNTPScreen"', 'name="ManualDateTimeScreen"').replace(
    'position="145,170" size="990,364" itemHeight="52"',
    'position="145,170" size="990,414" itemHeight="46"')


NTP_HELP_TEXTS = {
    "Local Time": "Current date and time of the receiver (local clock)",
    "Internet Time": "Date and time received from NTP servers on the internet",
    "Difference": "Clock offset between local time and internet time in seconds",
    "Status": "Current state of the NTP synchronization process",
    "Synchronize with NTP": "Press OK to synchronize the receiver clock with internet NTP servers",
    "Refresh Internet Time": "Press OK to fetch a new NTP time sample from the internet",
    "Manual Date/Time": "Press OK to open the manual date and time entry screen",
}

MANUAL_HELP_TEXTS = {
    "Year": "Set the year (2000 - 2099)",
    "Month": "Set the month number  (1 = Jan ... 12 = Dec)",
    "Day": "Set the day of the month  (1 - 31)",
    "Hour": "Set the hour in 24-hour format  (0 - 23)",
    "Minute": "Set the minutes  (0 - 59)",
    "Second": "Set the seconds  (0 - 59)",
    "Status": "Shows the result of the last save or validation attempt",
    "Refresh current date/time": "Press OK to load the current receiver time into the fields above",
    "Return to NTP Mode": "Press OK to go back to NTP synchronization mode",
}


try:
    text_type = unicode
    binary_type = str
    PYTHON2 = True
except NameError:
    text_type = str
    binary_type = bytes
    PYTHON2 = False


def toText(value):
    if value is None:
        return text_type("")
    if isinstance(value, text_type):
        return value
    if isinstance(value, binary_type):
        try:
            return value.decode("utf-8", "replace")
        except Exception:
            pass
    try:
        return text_type(value)
    except Exception:
        return text_type("")


def uiText(value):
    text = toText(value)
    if PYTHON2:
        return text.encode("utf-8", "replace")
    return text


def readVersion():
    try:
        with io.open(VERSION_FILE, "r", encoding="utf-8") as handle:
            version = handle.read().strip()
        if version:
            return version
    except Exception:
        pass
    return "unknown"


def outputText(value):
    if isinstance(value, (list, tuple)):
        return text_type("").join(toText(part) for part in value)
    return toText(value)


def readOnlyValue(value):
    text = uiText(value)
    return NoSave(ConfigSelection(choices=[(text, text)], default=text))


def setReadOnlyValue(element, value):
    text = uiText(value)
    choices = [(text, text)]
    try:
        element.setChoices(choices, default=text)
    except TypeError:
        element.setChoices(choices)
    element.value = text


def initializeConfigList(screen, entries, session):
    try:
        ConfigListScreen.__init__(screen, entries, session=session)
    except TypeError:
        ConfigListScreen.__init__(screen, entries)


PLUGIN_VERSION = readVersion()


class ManualDateTimeScreen(Screen, ConfigListScreen):
    skin = MANUAL_SCREEN_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        self.console = Console()
        self.saving = False
        self._is_closed = False

        self["key_red"] = StaticText("Exit")
        self["key_green"] = StaticText("Save")
        self["key_yellow"] = StaticText("Refresh")
        self["key_blue"] = StaticText("NTP Mode")
        self["subtitle"] = StaticText(
            "Set the receiver clock manually, then press the green button")
        self["description"] = StaticText(uiText(MANUAL_HELP_TEXTS["Year"]))

        now = time.localtime()
        self.year = NoSave(ConfigInteger(default=now.tm_year, limits=(2000, 2099)))
        self.month = NoSave(ConfigInteger(default=now.tm_mon, limits=(1, 12)))
        self.day = NoSave(ConfigInteger(default=now.tm_mday, limits=(1, 31)))
        self.hour = NoSave(ConfigInteger(default=now.tm_hour, limits=(0, 23)))
        self.minute = NoSave(ConfigInteger(default=now.tm_min, limits=(0, 59)))
        self.second = NoSave(ConfigInteger(default=now.tm_sec, limits=(0, 59)))
        self.status = readOnlyValue(time.strftime("%Y-%m-%d %H:%M:%S", now))
        self.refresh_action = readOnlyValue("Press OK")
        self.ntp_action = readOnlyValue("Press OK")

        self.list = [
            getConfigListEntry("Year", self.year),
            getConfigListEntry("Month", self.month),
            getConfigListEntry("Day", self.day),
            getConfigListEntry("Hour", self.hour),
            getConfigListEntry("Minute", self.minute),
            getConfigListEntry("Second", self.second),
            getConfigListEntry("Status", self.status),
            getConfigListEntry("Refresh current date/time", self.refresh_action),
            getConfigListEntry("Return to NTP Mode", self.ntp_action),
        ]
        initializeConfigList(self, self.list, session)

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {
                "cancel": self.close,
                "ok": self.activateSelected,
                "red": self.close,
                "green": self.saveDateTime,
                "yellow": self.loadCurrentDateTime,
                "blue": self.close,
            },
            -2,
        )
        self.setTitle(uiText(
            "Manual Mode By iet5 - v%s" % PLUGIN_VERSION))
        self.onClose.append(self.screenClosed)
        self.onClose.append(self._cleanupConsole)
        try:
            self["config"].onSelectionChanged.append(self.selectionChanged)
        except Exception:
            pass
        self.selectionChanged()

    def _cleanupConsole(self):
        try:
            self.console.killAll()
        except Exception:
            pass

    def screenClosed(self):
        self._is_closed = True

    def selectionChanged(self):
        if self._is_closed:
            return
        try:
            current = self["config"].getCurrent()
        except Exception:
            current = None
        text = ""
        if current:
            text = MANUAL_HELP_TEXTS.get(toText(current[0]), "")
        try:
            self["description"].setText(uiText(text))
        except Exception:
            pass

    def refreshList(self):
        if self._is_closed:
            return
        try:
            self["config"].setList(self.list)
        except Exception:
            try:
                self["config"].l.setList(self.list)
            except Exception:
                pass

    def activateSelected(self):
        try:
            current = self["config"].getCurrent()
        except Exception:
            current = None
        if not current:
            return
        if current[1] is self.refresh_action:
            self.loadCurrentDateTime()
        elif current[1] is self.ntp_action:
            self.close()

    def loadCurrentDateTime(self):
        if self._is_closed:
            return
        now = time.localtime()
        self.year.value = now.tm_year
        self.month.value = now.tm_mon
        self.day.value = now.tm_mday
        self.hour.value = now.tm_hour
        self.minute.value = now.tm_min
        self.second.value = now.tm_sec
        setReadOnlyValue(
            self.status, time.strftime("%Y-%m-%d %H:%M:%S", now))
        self.refreshList()

    def enteredDateTime(self):
        return (self.year.value, self.month.value, self.day.value,
                self.hour.value, self.minute.value, self.second.value)

    def saveDateTime(self):
        if self._is_closed or self.saving:
            return
        entered = self.enteredDateTime()
        try:
            datetime.datetime(*entered)
        except Exception as error:
            setReadOnlyValue(self.status, "Invalid date/time: %s" % error)
            self.refreshList()
            return

        self.saving = True
        setReadOnlyValue(self.status, "Saving...")
        self.refreshList()
        command = "/usr/bin/dreambox-ntp-sync --set-time %d %d %d %d %d %d" % entered
        try:
            self.console.ePopen(command, self.saveFinished)
        except Exception as error:
            self.saving = False
            setReadOnlyValue(self.status, "Could not save: %s" % error)
            self.refreshList()

    def saveFinished(self, result, return_code, *args):
        if self._is_closed:
            return
        self.saving = False
        if return_code == 0:
            self.loadCurrentDateTime()
            setReadOnlyValue(self.status, "Success")
        else:
            setReadOnlyValue(
                self.status, "Save failed; check permissions and values")
        self.refreshList()


class DreamboxNTPScreen(Screen, ConfigListScreen):
    skin = NTP_SCREEN_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        self.console = Console()
        self.busy = False
        self._is_closed = False
        self.internet_timestamp = None

        self["key_red"] = StaticText("Exit")
        self["key_green"] = StaticText("Manual Mode")
        self["key_yellow"] = StaticText("Refresh")
        self["key_blue"] = StaticText("Remove")
        self["subtitle"] = StaticText(
            "Precise receiver time powered by Network Time Protocol")
        self["description"] = StaticText(uiText(NTP_HELP_TEXTS["Local Time"]))

        self.local_time = readOnlyValue("--")
        self.internet_time = readOnlyValue("--")
        self.difference = readOnlyValue("None")
        self.status = readOnlyValue("Ready")
        self.sync_action = readOnlyValue("Press OK")
        self.refresh_action = readOnlyValue("Press OK")
        self.manual_action = readOnlyValue("Press OK")
        self.list = [
            getConfigListEntry("Local Time", self.local_time),
            getConfigListEntry("Internet Time", self.internet_time),
            getConfigListEntry("Difference", self.difference),
            getConfigListEntry("Status", self.status),
            getConfigListEntry("Synchronize with NTP", self.sync_action),
            getConfigListEntry("Refresh Internet Time", self.refresh_action),
            getConfigListEntry("Manual Date/Time", self.manual_action),
        ]
        initializeConfigList(self, self.list, session)

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {
                "cancel": self.close,
                "ok": self.activateSelected,
                "red": self.close,
                "green": self.openManualMode,
                "yellow": self.refreshInternetTime,
                "blue": self.requestRemoval,
            },
            -2,
        )
        self.setTitle(uiText("NTP Mode By iet5 - v%s" % PLUGIN_VERSION))
        self.onShown.append(self.firstRefresh)
        self.onClose.append(self.screenClosed)
        self.onClose.append(self._cleanupConsole)
        try:
            self["config"].onSelectionChanged.append(self.selectionChanged)
        except Exception:
            pass
        self.selectionChanged()

    def _cleanupConsole(self):
        try:
            self.console.killAll()
        except Exception:
            pass

    def screenClosed(self):
        self._is_closed = True

    def selectionChanged(self):
        if self._is_closed:
            return
        try:
            current = self["config"].getCurrent()
        except Exception:
            current = None
        text = ""
        if current:
            text = NTP_HELP_TEXTS.get(toText(current[0]), "")
        try:
            self["description"].setText(uiText(text))
        except Exception:
            pass

    def refreshList(self):
        if self._is_closed:
            return
        try:
            self["config"].setList(self.list)
        except Exception:
            try:
                self["config"].l.setList(self.list)
            except Exception:
                pass

    def activateSelected(self):
        try:
            current = self["config"].getCurrent()
        except Exception:
            current = None
        if not current:
            return
        if current[1] is self.manual_action:
            self.openManualMode()
        elif current[1] is self.sync_action:
            self.synchronizeNow()
        elif current[1] is self.refresh_action:
            self.refreshInternetTime()

    def updateLocalTime(self):
        if self._is_closed:
            return
        now = time.time()
        setReadOnlyValue(
            self.local_time,
            time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(now)))
        if self.internet_timestamp is not None:
            setReadOnlyValue(
                self.difference, "%+.3f seconds" %
                (self.internet_timestamp - now))
        else:
            setReadOnlyValue(self.difference, "None")
        self.refreshList()

    def firstRefresh(self):
        if self._is_closed:
            return
        try:
            self.onShown.remove(self.firstRefresh)
        except Exception:
            pass
        self.selectionChanged()
        self.refreshInternetTime()

    def refreshInternetTime(self):
        if self._is_closed or self.busy:
            return
        self.busy = True
        self.updateLocalTime()
        setReadOnlyValue(self.status, "Reading internet time...")
        self.refreshList()
        try:
            self.console.ePopen(PROBE_COMMAND, self.probeFinished)
        except Exception as error:
            self.busy = False
            setReadOnlyValue(
                self.status, "Could not start NTP check: %s" % error)
            self.refreshList()

    def probeFinished(self, result, return_code, *args):
        if self._is_closed:
            return
        self.busy = False
        timestamp = None
        if return_code == 0:
            for line in outputText(result).splitlines():
                if line.startswith("NTP_TIMESTAMP="):
                    try:
                        timestamp = float(line.split("=", 1)[1])
                    except Exception:
                        timestamp = None
        self.internet_timestamp = timestamp
        if timestamp is None:
            setReadOnlyValue(self.internet_time, "Unavailable")
            setReadOnlyValue(
                self.status, "NTP check failed; verify the internet connection")
        else:
            setReadOnlyValue(
                self.internet_time,
                time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(timestamp)))
            setReadOnlyValue(self.status, "Internet time received")
        self.updateLocalTime()

    def synchronizeNow(self):
        if self._is_closed or self.busy:
            return
        self.busy = True
        setReadOnlyValue(self.status, "Synchronizing...")
        self.refreshList()
        try:
            self.console.ePopen(SYNC_COMMAND, self.synchronizationFinished)
        except Exception as error:
            self.busy = False
            setReadOnlyValue(
                self.status, "Could not start synchronization: %s" % error)
            self.refreshList()

    def synchronizationFinished(self, result, return_code, *args):
        if self._is_closed:
            return
        self.busy = False
        if return_code == 0:
            setReadOnlyValue(self.status, "Time synchronized successfully")
            self.refreshList()
            # Guard: only probe if screen is still open and not already busy
            if not self._is_closed and not self.busy:
                self.refreshInternetTime()
        else:
            setReadOnlyValue(self.status, "Synchronization failed")
            self.updateLocalTime()

    def openManualMode(self):
        if self._is_closed:
            return
        self.session.openWithCallback(self.manualModeClosed, ManualDateTimeScreen)

    def requestRemoval(self):
        if self._is_closed:
            return
        if self.busy:
            setReadOnlyValue(
                self.status, "Please wait for the current operation to finish")
            self.refreshList()
            return
        self.session.openWithCallback(
            self.removalConfirmed,
            MessageBox,
            "Remove Dreambox NTP Sync and restore the receiver settings?",
            type=MessageBox.TYPE_YESNO,
            default=False,
        )

    def removalConfirmed(self, confirmed):
        if self._is_closed or not confirmed or self.busy:
            return
        self.busy = True
        setReadOnlyValue(self.status, "Removing plugin...")
        self.refreshList()
        command = (
            "DREAMBOX_NTP_UI_REMOVE=1 "
            "/usr/bin/dpkg --purge dreambox-ntp-sync")
        try:
            self.console.ePopen(command, self.removalFinished)
        except Exception as error:
            self.busy = False
            setReadOnlyValue(
                self.status, "Could not start removal: %s" % error)
            self.refreshList()

    def removalFinished(self, result, return_code, *args):
        if self._is_closed:
            return
        self.busy = False
        if return_code == 0:
            setReadOnlyValue(
                self.status, "Plugin removed; restarting Enigma2...")
            self.refreshList()
            try:
                self.console.ePopen(
                    "systemctl restart enigma2.service",
                    self.restartFinished)
            except Exception:
                pass
            return
        else:
            setReadOnlyValue(
                self.status, "Removal failed; use dpkg from the terminal")
        self.refreshList()

    def restartFinished(self, result, return_code, *args):
        return

    def manualModeClosed(self, *args):
        if self._is_closed:
            return
        self.internet_timestamp = None
        self.updateLocalTime()


def openScreen(session, **kwargs):
    session.open(DreamboxNTPScreen)


def Plugins(**kwargs):
    descriptor = {
        "name": "Dreambox NTP Sync By iet5",
        "description": "Automatic, NTP and manual date/time control",
        "where": PluginDescriptor.WHERE_PLUGINMENU,
        "fnc": openScreen,
    }
    icon_path = os.path.join(os.path.dirname(__file__), "plugin.png")
    if os.path.exists(icon_path):
        descriptor["icon"] = "plugin.png"
    return [PluginDescriptor(**descriptor)]
