#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function

import os
import socket
import struct
import subprocess
import sys
import time
import datetime
import io


__author__ = "iet5"

NTP_PORT = 123
NTP_EPOCH_DELTA = 2208988800
NTP_ERA_SECONDS = 4294967296.0
NTP_PACKET = b"\x1b" + (b"\0" * 47)
BOOT_RETRY_ATTEMPTS = 24
BOOT_RETRY_INTERVAL = 10.0
MANUAL_RETRY_ATTEMPTS = 12
MANUAL_RETRY_INTERVAL = 5.0
SERVERS = (
    "162.159.200.1",
    "0.africa.pool.ntp.org",
    "1.africa.pool.ntp.org",
    "0.pool.ntp.org",
)
LOG_FILE = "/tmp/dreambox-ntp-sync.log"
SETTINGS_FILE = "/etc/enigma2/settings"
LOCK_FILE = "/tmp/dreambox-ntp-sync.lock"
VERSION_FILE = (
    "/usr/lib/enigma2/python/Plugins/Extensions/DreamboxNTP/ver.txt")


try:
    text_type = unicode
    binary_type = str
except NameError:
    text_type = str
    binary_type = bytes


def to_text(value):
    if value is None:
        return text_type("")
    if isinstance(value, text_type):
        return value
    if isinstance(value, binary_type):
        try:
            return value.decode("utf-8", "replace")
        except Exception:
            pass
    try:
        return text_type(value)
    except Exception:
        return text_type("")


def read_version():
    try:
        with io.open(VERSION_FILE, "r", encoding="utf-8") as handle:
            value = handle.read().strip()
        if value:
            return value
    except Exception:
        pass
    return "unknown"


VERSION = read_version()


def write_stdout(message):
    line = to_text(message) + text_type("\n")
    try:
        sys.stdout.write(line)
    except UnicodeEncodeError:
        try:
            stream = getattr(sys.stdout, "buffer", sys.stdout)
            stream.write(line.encode("utf-8", "replace"))
        except Exception:
            pass
    except Exception:
        pass


def log(message):
    try:
        line = text_type("[DreamboxNTP] %s %s") % (
            time.strftime("%Y-%m-%d %H:%M:%S"), to_text(message))
        with io.open(LOG_FILE, "a", encoding="utf-8") as handle:
            handle.write(line + "\n")
        write_stdout(line)
    except Exception:
        pass


def byte_value(value):
    return value if isinstance(value, int) else ord(value)


def acquire_process_lock():
    try:
        import fcntl
    except Exception:
        return None
    try:
        handle = open(LOCK_FILE, "a+")
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return handle
    except (IOError, OSError):
        try:
            handle.close()
        except Exception:
            pass
        return False


def release_process_lock(handle):
    if not handle:
        return
    try:
        import fcntl
        fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
    except Exception:
        pass
    try:
        handle.close()
    except Exception:
        pass


def ntp_to_unix(seconds, fraction):
    candidate = float(seconds) - NTP_EPOCH_DELTA
    reference = max(time.time(), 1577836800.0)
    candidates = [candidate + (era * NTP_ERA_SECONDS)
                  for era in range(-2, 3)]
    nearest = min(candidates, key=lambda value: abs(value - reference))
    return nearest + (float(fraction) / NTP_ERA_SECONDS)


def query_server(server, timeout_value=0.75):
    try:
        try:
            socket.inet_aton(server)
            addresses = [
                (socket.AF_INET, socket.SOCK_DGRAM, 0, "",
                 (server, NTP_PORT))]
        except (socket.error, ValueError):
            addresses = socket.getaddrinfo(
                server, NTP_PORT, 0, socket.SOCK_DGRAM)
        addresses.sort(
            key=lambda item: 0 if item[0] == socket.AF_INET else 1)
    except Exception as error:
        return None, "DNS/address error: %s" % error

    last_error = "no usable address"
    for family, socktype, proto, _canon, sockaddr in addresses[:2]:
        client = None
        try:
            client = socket.socket(family, socktype, proto)
            client.settimeout(timeout_value)
            started = time.time()
            client.connect(sockaddr)
            client.send(NTP_PACKET)
            payload = client.recv(512)
            elapsed = max(0.0, min(2.0, time.time() - started))
            if len(payload) < 48:
                raise ValueError("short NTP reply")
            header = byte_value(payload[0])
            leap = (header >> 6) & 3
            version = (header >> 3) & 7
            mode = header & 7
            if leap == 3:
                raise ValueError("NTP server clock is unsynchronized")
            if version < 3:
                raise ValueError("unsupported NTP version")
            stratum = byte_value(payload[1])
            if mode != 4:
                raise ValueError("reply is not NTP server mode")
            if stratum < 1 or stratum > 15:
                raise ValueError("invalid NTP stratum")
            tx_seconds, tx_fraction = struct.unpack("!II", payload[40:48])
            if tx_seconds == 0:
                raise ValueError("empty NTP transmit timestamp")
            timestamp = ntp_to_unix(tx_seconds, tx_fraction) + (elapsed / 2.0)
            return timestamp, ""
        except Exception as error:
            last_error = str(error)
        finally:
            try:
                if client is not None:
                    client.close()
            except Exception:
                pass
    return None, last_error


def probe_network_time():
    last_error = "no server replied"
    for server in SERVERS:
        timestamp, error = query_server(server, timeout_value=1.0)
        if timestamp is not None:
            write_stdout("NTP_TIMESTAMP=%.6f" % timestamp)
            write_stdout("NTP_SERVER=%s" % server)
            return True
        last_error = "%s: %s" % (server, error)
    write_stdout("NTP_ERROR=%s" % last_error)
    return False


def set_system_time_with_date(timestamp):
    utc_value = time.strftime(
        "%Y-%m-%d %H:%M:%S", time.gmtime(float(timestamp)))
    commands = []
    for executable in ("/bin/date", "/usr/bin/date"):
        if os.path.isfile(executable) and os.access(executable, os.X_OK):
            commands.append([executable, "-u", "-s", utc_value])
            commands.append([executable, "-u", "-s", "@%d" % int(timestamp)])
    with open(os.devnull, "wb") as null_output:
        for command in commands:
            try:
                if subprocess.call(
                        command, stdout=null_output,
                        stderr=null_output) == 0:
                    return True
            except Exception:
                pass
    return False


def set_system_time(timestamp):
    try:
        import ctypes
    except Exception as error:
        if set_system_time_with_date(timestamp):
            return
        raise RuntimeError("ctypes is unavailable: %s" % to_text(error))

    libc = None
    last_error = "libc could not be loaded"
    for library_name in ("libc.so.6", "libc.so"):
        try:
            try:
                libc = ctypes.CDLL(library_name, use_errno=True)
            except TypeError:
                libc = ctypes.CDLL(library_name)
            break
        except Exception as error:
            last_error = str(error)
    if libc is None:
        if set_system_time_with_date(timestamp):
            return
        raise RuntimeError(to_text(last_error))

    class Timespec(ctypes.Structure):
        _fields_ = [
            ("tv_sec", ctypes.c_long),
            ("tv_nsec", ctypes.c_long),
        ]

    class Timeval(ctypes.Structure):
        _fields_ = [
            ("tv_sec", ctypes.c_long),
            ("tv_usec", ctypes.c_long),
        ]

    seconds = int(timestamp)
    microseconds = int((float(timestamp) - seconds) * 1000000)

    if hasattr(libc, "clock_settime"):
        value = Timespec(seconds, microseconds * 1000)
        try:
            libc.clock_settime.argtypes = [
                ctypes.c_int, ctypes.POINTER(Timespec)]
            libc.clock_settime.restype = ctypes.c_int
        except Exception:
            pass
        if libc.clock_settime(0, ctypes.byref(value)) == 0:
            return

    if hasattr(libc, "settimeofday"):
        value = Timeval(seconds, microseconds)
        try:
            libc.settimeofday.argtypes = [
                ctypes.POINTER(Timeval), ctypes.c_void_p]
            libc.settimeofday.restype = ctypes.c_int
        except Exception:
            pass
        if libc.settimeofday(ctypes.byref(value), None) == 0:
            return

    error_number = ctypes.get_errno()
    if set_system_time_with_date(timestamp):
        return
    if error_number:
        raise OSError(error_number, os.strerror(error_number))
    raise RuntimeError("clock_settime and settimeofday failed")


def set_manual_date_time(year, month, day, hour, minute, second):
    lock_handle = acquire_process_lock()
    if lock_handle is False:
        log("manual time update skipped because synchronization is already running")
        return False
    try:
        value = datetime.datetime(
            year, month, day, hour, minute, second)
        timestamp = time.mktime(value.timetuple())
        set_system_time(timestamp)
        disable_transponder_time()
        log("time set manually to %04d-%02d-%02d %02d:%02d:%02d" % (
            year, month, day, hour, minute, second))
        return True
    except Exception as error:
        log("manual time update failed: %s" % error)
        return False
    finally:
        release_process_lock(lock_handle)


def disable_transponder_time():
    key = b"config.misc.useTransponderTime="
    replacement = key + b"false\n"
    temporary = None
    try:
        try:
            with open(SETTINGS_FILE, "rb") as handle:
                lines = handle.readlines()
        except IOError:
            lines = []
        updated = []
        found = False
        changed = False
        for line in lines:
            if line.startswith(key):
                found = True
                if line != replacement:
                    changed = True
                updated.append(replacement)
            else:
                updated.append(line)
        if not found:
            if updated and not updated[-1].endswith(b"\n"):
                updated[-1] += b"\n"
            updated.append(replacement)
            changed = True
        if not changed:
            return True
        directory = os.path.dirname(SETTINGS_FILE)
        if not os.path.isdir(directory):
            try:
                os.makedirs(directory)
            except OSError:
                if not os.path.isdir(directory):
                    raise
        temporary = SETTINGS_FILE + ".dreambox-ntp.%d.tmp" % os.getpid()
        with open(temporary, "wb") as handle:
            handle.writelines(updated)
            handle.flush()
            os.fsync(handle.fileno())
        if hasattr(os, "replace"):
            os.replace(temporary, SETTINGS_FILE)
        else:
            os.rename(temporary, SETTINGS_FILE)
        log("DVB/transponder time disabled in Enigma2 settings")
        return True
    except Exception as error:
        try:
            if temporary and os.path.exists(temporary):
                os.remove(temporary)
        except Exception:
            pass
        log("could not disable transponder time: %s" % error)
        return False


def synchronize_unlocked(wait_seconds, log_failure=True):
    disable_transponder_time()
    deadline = time.time() + max(0.0, float(wait_seconds))
    first_cycle = True
    last_error = ""
    while first_cycle or time.time() < deadline:
        first_cycle = False
        queried_server = False
        for server in SERVERS:
            if queried_server and time.time() >= deadline:
                break
            queried_server = True
            timestamp, error = query_server(server)
            if timestamp is None:
                last_error = "%s: %s" % (server, error)
                continue
            try:
                set_system_time(timestamp)
                log("time synchronized from %s" % server)
                return True
            except Exception as set_error:
                last_error = "clock update failed: %s" % set_error
        if time.time() < deadline:
            time.sleep(0.25)
    if log_failure:
        log("synchronization skipped after bounded wait: %s" % last_error)
    return False


def synchronize(wait_seconds, log_failure=True):
    lock_handle = acquire_process_lock()
    if lock_handle is False:
        if log_failure:
            log("synchronization skipped because another update is running")
        return False
    try:
        return synchronize_unlocked(wait_seconds, log_failure)
    finally:
        release_process_lock(lock_handle)


def retry_synchronization(attempts, interval_seconds, reason):
    log("%s synchronization retries started" % reason)
    for attempt in range(1, attempts + 1):
        if synchronize(1.0, log_failure=False):
            return True
        if attempt < attempts:
            time.sleep(interval_seconds)
    log("%s synchronization retries expired; periodic timer will retry" % reason)
    return False


def main():
    if "--version" in sys.argv:
        write_stdout("Dreambox NTP Sync %s" % VERSION)
        return 0
    if "--probe" in sys.argv:
        return 0 if probe_network_time() else 1
    if "--set-time" in sys.argv:
        position = sys.argv.index("--set-time")
        values = sys.argv[position + 1:position + 7]
        if len(values) != 6:
            log("manual time update failed: expected year month day hour minute second")
            return 2
        try:
            values = [int(value) for value in values]
        except ValueError:
            log("manual time update failed: date and time must be numeric")
            return 2
        return 0 if set_manual_date_time(*values) else 1
    if "--boot-retry" in sys.argv:
        retry_synchronization(
            BOOT_RETRY_ATTEMPTS, BOOT_RETRY_INTERVAL, "boot")
        return 0
    if "--manual" in sys.argv:
        if retry_synchronization(
                MANUAL_RETRY_ATTEMPTS, MANUAL_RETRY_INTERVAL, "manual"):
            return 0
        return 1
    wait_seconds = 6.0
    if "--quick" in sys.argv:
        wait_seconds = 1.0
    synchronize(wait_seconds)
    return 0


if __name__ == "__main__":
    sys.exit(main())
