#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function

import os
import socket
import struct
import sys
import time


NTP_PORT = 123
NTP_EPOCH_DELTA = 2208988800
NTP_PACKET = b"\x1b" + (b"\0" * 47)
VERSION = "1.1.0"
SERVERS = (
    "162.159.200.1",
    "0.africa.pool.ntp.org",
    "1.africa.pool.ntp.org",
    "0.pool.ntp.org",
)
LOG_FILE = "/tmp/dreambox-ntp-sync.log"
SETTINGS_FILE = "/etc/enigma2/settings"


def log(message):
    try:
        line = "[DreamboxNTP] %s %s" % (
            time.strftime("%Y-%m-%d %H:%M:%S"), message)
        with open(LOG_FILE, "a") as handle:
            handle.write(line + "\n")
        print(line)
    except Exception:
        pass


def byte_value(value):
    return value if isinstance(value, int) else ord(value)


def query_server(server, timeout_value=0.75):
    try:
        addresses = socket.getaddrinfo(
            server, NTP_PORT, 0, socket.SOCK_DGRAM)
        addresses.sort(
            key=lambda item: 0 if item[0] == socket.AF_INET else 1)
    except Exception as error:
        return None, "DNS/address error: %s" % error

    last_error = "no usable address"
    for family, socktype, proto, _canon, sockaddr in addresses[:2]:
        client = None
        try:
            client = socket.socket(family, socktype, proto)
            client.settimeout(timeout_value)
            started = time.time()
            client.sendto(NTP_PACKET, sockaddr)
            payload, _peer = client.recvfrom(512)
            elapsed = max(0.0, min(2.0, time.time() - started))
            if len(payload) < 48:
                raise ValueError("short NTP reply")
            mode = byte_value(payload[0]) & 7
            stratum = byte_value(payload[1])
            if mode != 4:
                raise ValueError("reply is not NTP server mode")
            if stratum < 1 or stratum > 15:
                raise ValueError("invalid NTP stratum")
            tx_seconds, tx_fraction = struct.unpack("!II", payload[40:48])
            if tx_seconds == 0:
                raise ValueError("empty NTP transmit timestamp")
            timestamp = (
                float(tx_seconds - NTP_EPOCH_DELTA) +
                (float(tx_fraction) / 4294967296.0) +
                (elapsed / 2.0)
            )
            return timestamp, ""
        except Exception as error:
            last_error = str(error)
        finally:
            try:
                if client is not None:
                    client.close()
            except Exception:
                pass
    return None, last_error


def set_system_time(timestamp):
    """Set the system clock through libc."""
    try:
        import ctypes
    except Exception as error:
        raise RuntimeError("ctypes is unavailable: %s" % error)

    libc = None
    last_error = "libc could not be loaded"
    for library_name in ("libc.so.6", "libc.so"):
        try:
            try:
                libc = ctypes.CDLL(library_name, use_errno=True)
            except TypeError:
                libc = ctypes.CDLL(library_name)
            break
        except Exception as error:
            last_error = str(error)
    if libc is None:
        raise RuntimeError(last_error)

    class Timespec(ctypes.Structure):
        _fields_ = [
            ("tv_sec", ctypes.c_long),
            ("tv_nsec", ctypes.c_long),
        ]

    class Timeval(ctypes.Structure):
        _fields_ = [
            ("tv_sec", ctypes.c_long),
            ("tv_usec", ctypes.c_long),
        ]

    seconds = int(timestamp)
    microseconds = int((float(timestamp) - seconds) * 1000000)

    if hasattr(libc, "clock_settime"):
        value = Timespec(seconds, microseconds * 1000)
        try:
            libc.clock_settime.argtypes = [
                ctypes.c_int, ctypes.POINTER(Timespec)]
            libc.clock_settime.restype = ctypes.c_int
        except Exception:
            pass
        if libc.clock_settime(0, ctypes.byref(value)) == 0:
            return

    if hasattr(libc, "settimeofday"):
        value = Timeval(seconds, microseconds)
        try:
            libc.settimeofday.argtypes = [
                ctypes.POINTER(Timeval), ctypes.c_void_p]
            libc.settimeofday.restype = ctypes.c_int
        except Exception:
            pass
        if libc.settimeofday(ctypes.byref(value), None) == 0:
            return

    error_number = ctypes.get_errno()
    if error_number:
        raise OSError(error_number, os.strerror(error_number))
    raise RuntimeError("clock_settime and settimeofday failed")


def disable_transponder_time():
    """Disable DVB time in the Enigma2 settings."""
    key = "config.misc.useTransponderTime="
    replacement = key + "false\n"
    try:
        try:
            with open(SETTINGS_FILE, "r") as handle:
                lines = handle.readlines()
        except IOError:
            lines = []
        updated = []
        found = False
        changed = False
        for line in lines:
            if line.startswith(key):
                found = True
                if line != replacement:
                    changed = True
                updated.append(replacement)
            else:
                updated.append(line)
        if not found:
            if updated and not updated[-1].endswith("\n"):
                updated[-1] += "\n"
            updated.append(replacement)
            changed = True
        if not changed:
            return True
        directory = os.path.dirname(SETTINGS_FILE)
        if not os.path.isdir(directory):
            os.makedirs(directory)
        temporary = SETTINGS_FILE + ".dreambox-ntp.tmp"
        with open(temporary, "w") as handle:
            handle.writelines(updated)
            handle.flush()
            os.fsync(handle.fileno())
        os.rename(temporary, SETTINGS_FILE)
        log("DVB/transponder time disabled in Enigma2 settings")
        return True
    except Exception as error:
        log("could not disable transponder time: %s" % error)
        return False


def synchronize(wait_seconds):
    disable_transponder_time()
    deadline = time.time() + max(0.0, float(wait_seconds))
    first_cycle = True
    last_error = ""
    while first_cycle or time.time() < deadline:
        first_cycle = False
        for server in SERVERS:
            timestamp, error = query_server(server)
            if timestamp is None:
                last_error = "%s: %s" % (server, error)
                continue
            try:
                set_system_time(timestamp)
                log("time synchronized from %s" % server)
                return True
            except Exception as set_error:
                last_error = "clock update failed: %s" % set_error
        if time.time() < deadline:
            time.sleep(0.25)
    log("synchronization skipped after bounded wait: %s" % last_error)
    return False


def main():
    if "--version" in sys.argv:
        print("Dreambox NTP Sync %s" % VERSION)
        return 0
    wait_seconds = 6.0
    if "--quick" in sys.argv:
        wait_seconds = 1.0
    synchronize(wait_seconds)
    return 0


if __name__ == "__main__":
    sys.exit(main())
