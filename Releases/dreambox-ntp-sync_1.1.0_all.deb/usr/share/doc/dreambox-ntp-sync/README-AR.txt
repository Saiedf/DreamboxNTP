Dreambox NTP Sync 1.1.0 - Universal Enigma2 edition
==================================================

الأجهزة والصور المستهدفة:
- أجهزة Dreambox القديمة والجديدة التي تعمل بواجهة Enigma2.
- معماريات MIPS وARM وAArch64.
- Python 2.7 وPython 3.
- صور systemd وصور SysV القديمة.

الوظيفة:
- يوقف اعتماد Enigma2 على توقيت القناة أو الترانسبوندر.
- يضبط وقت Linux بواسطة NTP قبل تشغيل Enigma2 قدر الإمكان.
- ينتظر الإنترنت بحد أقصى 6 ثوانٍ فقط، ولا يمنع إقلاع الجهاز عند فشل الشبكة.
- يعيد مزامنة الوقت كل 30 دقيقة.
- يختار Python الموجود في الصورة تلقائيًا، ولا يحتوي على ملف تنفيذي خاص بمعمارية واحدة.
- يعمل في الخلفية ولا يعرض رسائل منبثقة على الشاشة.

الخوادم بالترتيب:
1. 162.159.200.1 (Cloudflare IPv4 Anycast، بدون انتظار DNS)
2. 0.africa.pool.ntp.org
3. 1.africa.pool.ntp.org
4. 0.pool.ntp.org

التثبيت بواسطة الحزمة:
- تتطلب الحزمة صورة تستخدم مدير الحزم dpkg وتدعم ملفات DEB.
- عند تثبيت الإصدار 1.1.0 فوق إصدار أقدم، يتولى مدير الحزم ترقية الحزمة وإزالة ملفات الإصدار السابق تلقائيًا.

التثبيت اليدوي على صورة systemd:
1. انسخ محتويات هذا المجلد فوق جذر ملفات الصورة مع الحفاظ على المسارات.
2. نفّذ:
   chmod 755 /usr/bin/dreambox-ntp-sync
   chmod 755 /etc/rcS.d/S39dreambox-ntp-sync
   chmod 644 /usr/lib/dreambox-ntp-sync.py
   chmod 644 /lib/systemd/system/dreambox-ntp-sync.service
   chmod 644 /lib/systemd/system/dreambox-ntp-sync.timer
   chmod 644 /etc/systemd/system/enigma2.service.d/10-dreambox-ntp-sync.conf
   systemctl daemon-reload
   systemctl enable --now dreambox-ntp-sync.timer
   systemctl restart enigma2

على صور SysV القديمة:
- يكفي نسخ الملفات وضبط الصلاحيات السابقة ثم إعادة تشغيل الجهاز بالكامل.
- يعمل ملف /etc/rcS.d/S39dreambox-ntp-sync تلقائيًا، ويتوقف عن التدخل إذا اكتشف أن الصورة تستخدم systemd.

الفحص على systemd:
   systemctl status dreambox-ntp-sync.service
   systemctl status dreambox-ntp-sync.timer
   cat /tmp/dreambox-ntp-sync.log

الفحص على أي صورة:
   /usr/bin/dreambox-ntp-sync --version
   /usr/bin/dreambox-ntp-sync --quick
   cat /tmp/dreambox-ntp-sync.log
   date

ملاحظة:
- احذف أو عطّل أي إضافة أخرى لمزامنة الوقت حتى لا تعمل طريقتان لضبط الساعة في الوقت نفسه.

إلغاء الحزمة:
- نفّذ: dpkg -r dreambox-ntp-sync
